#!/bin/bash
mvn clean install
java -cp target/PlayerMavenProject com.example.Main